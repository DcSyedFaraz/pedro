        <label for="description">Description:</label>
        <input type="text" name="description" class="form-control description" id="description" required>
        
        <label for="amount">Amount:</label>
        <input type="number" step="0.01" name="amount" class="form-control amount" id="amount" required>